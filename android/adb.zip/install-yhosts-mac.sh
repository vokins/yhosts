curl https://raw.githubusercontent.com/vokins/yhosts/master/hosts
curl https://raw.githubusercontent.com/vokins/yhosts/master/android/hosts.zip
chmod +x fastboot-mac
./fastboot-mac adb devices
adb root
adb remount
adb push hosts /etc/hosts
adb shell chmod 600 /etc/hosts
adb shell reboot